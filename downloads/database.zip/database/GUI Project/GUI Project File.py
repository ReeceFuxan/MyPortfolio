"""
Instructions:
1. This program requires the Tkinter library for the graphical user interface.
   - If you don't have Tkinter installed, you can install it using pip:
     ```
     pip install tk
     ```
2. This program also requires SQLite for database operations.
   - If you don't have SQLite installed, you can install it using pip:
     ```
     pip install sqlite
     ```
3. Run the provided Python file. The program will automatically open a window for the Library Management System.
4. You can interact with the application window to manage the library.
"""
import tkinter as tk
from tkinter import messagebox
import sqlite3

# Function to initialize the database
def initialize_database():
    conn = sqlite3.connect('library.db')
    cursor = conn.cursor()

    cursor.execute('''CREATE TABLE IF NOT EXISTS Books (
                        book_id INTEGER PRIMARY KEY,
                        title TEXT,
                        author TEXT,
                        genre TEXT,
                        publisher TEXT,
                        publication_year INTEGER,
                        quantity INTEGER
                    )''')

    conn.commit()
    conn.close()

# Function to add a new book to the database
def add_book(title, author, genre, publisher, publication_year, quantity):
    conn = sqlite3.connect('library.db')
    cursor = conn.cursor()

    cursor.execute('''INSERT INTO Books (title, author, genre, publisher, publication_year, quantity)
                      VALUES (?, ?, ?, ?, ?, ?)''', (title, author, genre, publisher, publication_year, quantity))

    conn.commit()
    conn.close()

# Function to remove a book from the database
def remove_book(book_id):
    conn = sqlite3.connect('library.db')
    cursor = conn.cursor()

    cursor.execute("DELETE FROM Books WHERE book_id=?", (book_id,))

    conn.commit()
    conn.close()

# Function to update book information in the database
def update_book(book_id, title, author, genre, publisher, publication_year, quantity):
    conn = sqlite3.connect('library.db')
    cursor = conn.cursor()

    cursor.execute('''UPDATE Books SET title=?, author=?, genre=?, publisher=?, 
                      publication_year=?, quantity=? WHERE book_id=?''',
                   (title, author, genre, publisher, publication_year, quantity, book_id))

    conn.commit()
    conn.close()

# Function to search for books in the database
def search_books(title='', author='', genre='', publisher='', publication_year=''):
    conn = sqlite3.connect('library.db')
    cursor = conn.cursor()

    query = '''SELECT * FROM Books WHERE 
               title LIKE ? AND author LIKE ? AND genre LIKE ? AND publisher LIKE ? AND publication_year LIKE ?'''

    cursor.execute(query, ('%'+title+'%', '%'+author+'%', '%'+genre+'%', '%'+publisher+'%', '%'+publication_year+'%'))
    books = cursor.fetchall()

    conn.close()
    return books

# Function to handle the "Add Book" button click
def add_book_click():
    title = entry_title.get()
    author = entry_author.get()
    genre = entry_genre.get()
    publisher = entry_publisher.get()
    publication_year = entry_publication_year.get()
    quantity = entry_quantity.get()

    # Validate input fields
    if title == '' or author == '' or genre == '' or publisher == '' or publication_year == '' or quantity == '':
        messagebox.showerror("Error", "Please fill in all fields.")
        return

    # Ensure quantity is a positive integer
    try:
        quantity = int(quantity)
        if quantity <= 0:
            raise ValueError
    except ValueError:
        messagebox.showerror("Error", "Quantity must be a positive integer.")
        return

    # Add the book to the database
    add_book(title, author, genre, publisher, publication_year, quantity)

    # Show success message
    messagebox.showinfo("Success", "Book added successfully.")

# Function to handle the "Remove Book" button click
def remove_book_click():
    book_id = entry_book_id.get()

    # Validate input field
    if book_id == '':
        messagebox.showerror("Error", "Please enter a book ID.")
        return

    # Confirm book removal with the user
    response = messagebox.askyesno("Confirmation", "Are you sure you want to remove this book?")

    if response == True:
        remove_book(book_id)
        messagebox.showinfo("Success", "Book removed successfully.")
    else:
        messagebox.showinfo("Info", "Book removal cancelled.")

# Function to handle the "Update Book" button click
def update_book_click():
    book_id = entry_book_id.get()
    title = entry_title.get()
    author = entry_author.get()
    genre = entry_genre.get()
    publisher = entry_publisher.get()
    publication_year = entry_publication_year.get()
    quantity = entry_quantity.get()

    # Validate input fields
    if book_id == '' or title == '' or author == '' or genre == '' or publisher == '' or publication_year == '' or quantity == '':
        messagebox.showerror("Error", "Please fill in all fields.")
        return

    # Ensure quantity is a positive integer
    try:
        quantity = int(quantity)
        if quantity <= 0:
            raise ValueError
    except ValueError:
        messagebox.showerror("Error", "Quantity must be a positive integer.")
        return

    # Update the book in the database
    update_book(book_id, title, author, genre, publisher, publication_year, quantity)

    # Show success message
    messagebox.showinfo("Success", "Book updated successfully.")

# Function to handle the "Search" button click
def search_click():
    title = entry_title.get()
    author = entry_author.get()
    genre = entry_genre.get()
    publisher = entry_publisher.get()
    publication_year = entry_publication_year.get()

    books = search_books(title, author, genre, publisher, publication_year)
    display_search_results(books)

# Function to display search results in the text widget
def display_search_results(books):
    result_text.delete('1.0', tk.END)  # Clear previous search results
    for book in books:
        result_text.insert(tk.END, f"Book ID: {book[0]}\n")
        result_text.insert(tk.END, f"Title: {book[1]}\n")
        result_text.insert(tk.END, f"Author: {book[2]}\n")
        result_text.insert(tk.END, f"Genre: {book[3]}\n")
        result_text.insert(tk.END, f"Publisher: {book[4]}\n")
        result_text.insert(tk.END, f"Publication Year: {book[5]}\n")
        result_text.insert(tk.END, f"Quantity: {book[6]}\n\n")

# Create the main application window
root = tk.Tk()
root.title("Library Management System")

# Initialize the database
initialize_database()

# Create and place widgets
label_title = tk.Label(root, text="Library Management System")
label_title.pack()

# Create a frame for book information
frame_book_info = tk.Frame(root)
frame_book_info.pack()

frame_entry = tk.Frame(root)
frame_entry.pack()

# Labels and entry fields for book information
label_book_id = tk.Label(frame_entry, text="Book ID:")
label_book_id.grid(row=6, column=0)
entry_book_id = tk.Entry(frame_entry)
entry_book_id.grid(row=6, column=1)

label_title = tk.Label(frame_book_info, text="Title:")
label_title.grid(row=0, column=0)
entry_title = tk.Entry(frame_book_info)
entry_title.grid(row=0, column=1)

label_author = tk.Label(frame_book_info, text="Author:")
label_author.grid(row=1, column=0)
entry_author = tk.Entry(frame_book_info)
entry_author.grid(row=1, column=1)

label_genre = tk.Label(frame_book_info, text="Genre:")
label_genre.grid(row=2, column=0)
entry_genre = tk.Entry(frame_book_info)
entry_genre.grid(row=2, column=1)

label_publisher = tk.Label(frame_book_info, text="Publisher:")
label_publisher.grid(row=3, column=0)
entry_publisher = tk.Entry(frame_book_info)
entry_publisher.grid(row=3, column=1)

label_publication_year = tk.Label(frame_book_info, text="Publication Year:")
label_publication_year.grid(row=4, column=0)
entry_publication_year = tk.Entry(frame_book_info)
entry_publication_year.grid(row=4, column=1)

label_quantity = tk.Label(frame_book_info, text="Quantity:")
label_quantity.grid(row=5, column=0)
entry_quantity = tk.Entry(frame_book_info)
entry_quantity.grid(row=5, column=1)

# Create a frame for action buttons
frame_buttons = tk.Frame(root)
frame_buttons.pack()

# Create action buttons
button_add = tk.Button(frame_buttons, text="Add Book", command=add_book_click)
button_add.grid(row=0, column=0, padx=5, pady=5)

button_remove = tk.Button(frame_buttons, text="Remove Book", command=remove_book_click)
button_remove.grid(row=0, column=1, padx=5, pady=5)

button_update = tk.Button(frame_buttons, text="Update Book", command=update_book_click)
button_update.grid(row=0, column=2, padx=5, pady=5)

button_search = tk.Button(frame_buttons, text="Search", command=search_click)
button_search.grid(row=0, column=3, padx=5, pady=5)

# Create a text widget with scrollbar for displaying search results
result_frame = tk.Frame(root)
result_frame.pack()

result_text = tk.Text(result_frame, height=10, width=50)
result_text.pack(side=tk.LEFT, fill=tk.Y)

scrollbar = tk.Scrollbar(result_frame, orient=tk.VERTICAL, command=result_text.yview)
scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

result_text.config(yscrollcommand=scrollbar.set)

# Run the Tkinter event loop
root.mainloop()