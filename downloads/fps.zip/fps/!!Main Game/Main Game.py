# ==================================================================== #
#                            GAME Imports                              #
import pygame
import random
from random import randint
# ==================================================================== #

# ==================================================================== #
#                             GAME Images                              #
background = pygame.image.load('City.png')
city = pygame.image.load('city no bgd.png')
# ==================================================================== #

# ==================================================================== #
#                            GAME SETTINGS                             #
TITLE = 'First Person Shooter'

BLOCK_SIZE = 87
WORLD_SIZE = 8
WIDTH = WORLD_SIZE*BLOCK_SIZE
HEIGHT = WORLD_SIZE*BLOCK_SIZE
gameStatus = 0  # 0:playing, 1: print scores
speed = 3
target_speed = 0.5
level = 1
level_completed = False
level_up = False
Str = str
# ==================================================================== #

# ==================================================================== #
#                           CREATING ACTORS                            #
fps = Actor('crosshair.png')
fps.x = 4 * BLOCK_SIZE
fps.y = 4 * BLOCK_SIZE
fps.dx = 0
fps.dy = 0
fps.score = 0
fps.ammo = 5
fps.name = 'Player 1'
fps.fired = False
# ==================================================================== #
target1 = Actor('missile1.png')
target1.x = 6 * BLOCK_SIZE
target1.y = 2 * BLOCK_SIZE
target1_width = 50
target1_height = 50
target1.value = 10
target1.dy = 0
target1.visible = True
target1.rect = pygame.Rect(target1.x, target1.y, target1_width, target1_height)

fps.colliderect(target1.rect)
# ==================================================================== #
target2 = Actor('missile2.png')
target2.x = 2 * BLOCK_SIZE
target2.y = 2 * BLOCK_SIZE
target2_width = 50
target2_height = 50
target2.value = 5
target2.dy = 0
target2.visible = True
target2.rect = pygame.Rect(target2.x, target2.y, target2_width, target2_height)

fps.colliderect(target2.rect)
# ==================================================================== #
gun = Actor('lasergun.png')
gun.visible = True

playing = True
# ==================================================================== #

# ==================================================================== #
#                           Actor Movement                             #
def on_key_down(key):
    global playing, level_completed, level_up
    print(key)
    if key == keys.RIGHT:
        print("Key Pressed: ", key)
        fps.dx = speed

    elif key == keys.LEFT:
        print("Key Pressed: ", key)
        fps.dx -= speed

    elif key == keys.DOWN:
        print("Key Pressed: ", key)
        fps.dy = speed

    elif key == keys.UP:
        print("Key Pressed: ", key)
        fps.dy -= speed
# ==================================================================== #

    elif key == keys.V and gun.visible== False:
        print("Gun Visible: ", key)
        gun.visible = True

    elif key == keys.V and gun.visible == True:
        print("Gun Not Visible: ", key)
        gun.visible = False
# ==================================================================== #

    elif key == keys.ESCAPE and playing == True:
        print("Game Paused", key)
        playing = False

    elif key == keys.ESCAPE and playing == False:
        print("Game Playing", key)
        playing = True
# ==================================================================== #

    elif key == keys.SPACE and fps.ammo > 0:
        fps.fired = True

    elif key == keys.R:
        fps.ammo += 5
        print("Ammo Reloaded", key,)
# ==================================================================== #
    elif key == keys.RETURN and level_completed == True:
        prepare_next_level()

    elif key == keys.S:
        saveGame()
        print("Game saved")

    elif key == keys.L:
        loadGame()
        print("Loading Game")
# ==================================================================== #

def on_key_up(key):
    if key == keys.RIGHT:
        print('Key pressed:', key)
        fps.dx = 0

    if key == keys.LEFT:
        print('Key pressed:', key)
        fps.dx = 0

    if key == keys.DOWN:
        print('Key pressed:', key,)
        fps.dy = 0

    if key == keys.UP:
        print('Key pressed:', key)
        fps.dy = 0
# ==================================================================== #
def on_mouse_down(pos, button):
    fps.pos = pos
# ==================================================================== #

# ==================================================================== #
#                           Screen Update                              #
def update():
    global playing, target_speed, level, level_completed
    if playing == False:
        fps.dx = 0
        fps.dy = 0
        target1.dy = 0
        target2.dy = 0
    if playing == True:
        target1.dy = target_speed
        target1.y += target1.dy
        target1.y %= 8*BLOCK_SIZE
        target1.rect.topleft = (target1.x, target1.y)

        target2.dy = target_speed
        target2.y += target2.dy
        target2.y %= 8*BLOCK_SIZE
        target2.rect.topleft = (target2.x, target2.y)

        fps.x = fps.x + fps.dx
        fps.y = fps.y + fps.dy
    print("Score", fps.score)
    print('dx= ', fps.dx)
    print('dy= ', fps.dy)
    print(fps.pos)
# ==================================================================== #
    if fps.colliderect(target1.rect) and fps.fired:
        target1.visible = False
        fps.score += target1.value
    if target1.visible == False:
        target1.value = 0
# ==================================================================== #
    if fps.colliderect(target2.rect) and fps.fired:
        target2.visible = False
        fps.score += target2.value
    if target2.visible == False:
        target2.value = 0
# ==================================================================== #
    if fps.fired:
        fps.fired = False
        fps.ammo -= 1
        choice = random.randint(1, 3)
        if choice == 1 or choice == 2:
            fps.image = ('explosion.png')
        elif choice == 3:
            fps.image = ('explosion2.png')
        clock.schedule(resetImage, 0.2)
    elif fps.ammo == 0:
        fps.fired = False
# ==================================================================== #
    if target1.visible == False and target2.visible == False:
        level_completed = True
        playing = False
        fps.ammo = 5

# ==================================================================== #
def prepare_next_level():
    global level_completed, playing, level_up, level, target_speed
    playing = True
    level_completed = False
    target1.visible = True
    target1.y = 1
    target2.visible = True
    target2.y = 1
    fps.ammo = 5
    level += 1
    target_speed += 0.1 * level
    target1.value += 1 * level
    target2.value += 1 * level
    level_up = False
    #if level_up == True:
# ==================================================================== #
#                           SCREEN DISPLAY                             #
def draw():
    screen.blit(background, (0, 0))
    if target1.visible == True:
        target1.draw()
    if target2.visible == True:
        target2.draw()
    screen.blit(city, (0, 0))
    screen.draw.text("Score: " + Str(fps.score), topleft=(8, 4), fontsize=40)
    screen.draw.text("Ammo: " + Str(fps.ammo), topleft=(WIDTH - 1.75*BLOCK_SIZE, 4), fontsize=40)
    screen.draw.text("Level: " + Str(level), topleft=(3.3*BLOCK_SIZE, 4), fontsize=40)
    fps.draw()
    if gun.visible and playing == True:
        gun.draw()
    if playing == False and level_completed == False:
        screen.draw.text("GAME PAUSED", topleft=(WIDTH / 3, BLOCK_SIZE * 4), fontsize= 40)
    if fps.fired == False and fps.ammo == 0:
        screen.draw.text(("Press R To Reload Ammo"), topleft=(WIDTH / 4, BLOCK_SIZE * 4.5), fontsize= 40)
    if level_completed == True:
        screen.draw.text(("Level Completed"), topleft=(WIDTH / 3, BLOCK_SIZE * 3.5), fontsize= 40)
        screen.draw.text(("Press Enter to Continue"), topleft=(WIDTH / 3.65, BLOCK_SIZE * 4), fontsize= 40)
# ==================================================================== #

# ==================================================================== #
#                            Game Saving                               #
def saveGame():
    print("Saving progress...")
    output = open("savestate.txt", "w")
    output.write(str(fps.x) +"\n")
    output.write(str(fps.y) +"\n")
    output.write(str(fps.score) +"\n")
    output.write(str(fps.ammo) +"\n")
    output.write(str(target1.x) + "\n")
    output.write(str(target1.y))
    output.close()
# ==================================================================== #

def loadGame():
    print("Loading progress...")
    input = open("savestate.txt", "r")
    fps.x = float(input.readline())
    fps.y = float(input.readline())
    fps.score = int(input.readline())
    fps.ammo = int(input.readline())
    target1.x = float(input.readline())
    target1.y = float(input.readline())
    input.close()
# ==================================================================== #

# ==================================================================== #
#                               Images                                 #
def resetImage():
    fps.image = 'crosshair.png'
# ==================================================================== #
saveGame()
loadGame()
